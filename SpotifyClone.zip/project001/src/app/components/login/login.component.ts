import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  login!: FormGroup;
  constructor(
    private fb: FormBuilder,
    private api: UserService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.login = this.fb.group({
      name: ['', Validators.required],
      password: ['', Validators.required],
    });
  }
  logIn() {
    this.api.getDetails().subscribe((res) => {
      console.log(res);

      let user = res.find(
        (x: any) =>
          x.password === this.login.value.password &&
          x.name === this.login.value.name
      );

      if (user) {
        alert('login is successful');
        this.login.reset();
        this.router.navigate(['/dashboard', user.id]);
      } else {
        alert('user not found');
      }
    });
  }

  submit() {
    if (this.login.valid) {
      this.api.postDetails(this.login.value).subscribe({
        next: (response) => {
          alert('login is successful');
          this.login.reset();
          this.router.navigate(['/playlist']);
        },
        error: () => {
          alert('login is not successful');
        },
      });
    }
  }

  get() {
    this.api.getDetails().subscribe((data) => {
      console.log(data[0].TotalPlaylists);
    });
  }
}
