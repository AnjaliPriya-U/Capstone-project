import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  audio: any;
  n: any = this.r.snapshot.paramMap.get('id')!;
  constructor(
    private l: Location,
    private r: ActivatedRoute,
    private api: UserService
  ) {}

  ngOnInit(): void {
    this.audio = new Audio();
  }

  goback() {
    this.l.back();
  }
  goforward() {
    this.l.forward();
  }
  startPlayer() {
    this.audio.src =
      'https://p.scdn.co/mp3-preview/55c290e3c4c6d0ccdb1fb16530dd6ca00f73cd94?cid=774b29d4f13844c495f206cafdad9c86';
    this.audio.load();
    this.audio.play();
  }
  pause() {
    this.audio.pause();
  }
}
