import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { ActivatedRoute } from '@angular/router';
import { SongService } from 'src/app/services/song.service';

@Component({
  selector: 'app-playlist',
  templateUrl: './playlist.component.html',
  styleUrls: ['./playlist.component.css'],
})
export class PlaylistComponent implements OnInit {
  playlist!: FormGroup;
  list: string[] = [];
  fruits: Array<string> = [];
  songs: any;
  audio: any;
  isShow: any = true;
  data: any;
  details: any;
  id: any = this.r.snapshot.paramMap.get('id')!;
  playlistname: any;
  songnames: [] = [];

  constructor(
    private fb: FormBuilder,
    private api: UserService,
    private router: Router,
    private r: ActivatedRoute,
    private service: SongService
  ) {}

  ngOnInit(): void {
    this.audio = new Audio();
    this.playlist = this.fb.group({
      name: ['', Validators.required],
      password: ['', Validators.required],
    });
    this.getDetails();
    console.log(this.id);
  }
  getDetails(): void {
    this.api.getSongDetails().subscribe((data: any) => {
      this.songs = data;
      console.log(this.songs);
    });
  }
  startPlayer(s: any) {
    this.audio.src = s;
    this.audio.load();
    this.audio.play();
    this.isShow = false;
  }
  pausePlayer() {
    this.audio.pause();
    this.isShow = true;
  }
  add(id: any) {
    this.list.push(id);
    console.log(this.list);
  }
  submit() {
    this.data = {
      PlaylistName: this.playlist.value.name,
      playlists: this.list,
    };
    console.log(this.data);

    this.service.updatePlaylist(this.id, this.data).subscribe({
      next: (response) => {
        alert('playlist is created');
      },
      error: () => {
        alert('playlist is not created');
      },
    });
  }

  view() {
    this.service.getPlaylist(this.id).subscribe((data) => {
      this.details = data;
      this.details = data.totalPlaylists;
      for (let i = 0; i < data.totalPlaylists.length; i++) {
        let element = data.totalPlaylists[i].playlistName;
        console.log('playlist name', element);
      }
      console.log('total playlists', data.totalPlaylists);

      for (let i = 0; i < this.details.length; i++) {
        const element = this.details[i];

        console.log('playlists', element.playlists);
        for (let i = 0; i < element.playlists.length; i++) {
          const s = element.playlists[i];

          for (let j = 0; j < this.songs.length; j++) {
            if (s == this.songs[j].id) {
              console.log('song name', this.songs[j].name);
            }
          }
        }
      }
    });
  }
}
