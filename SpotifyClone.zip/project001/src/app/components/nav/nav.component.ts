import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SongService } from 'src/app/services/song.service';
import { UserService } from 'src/app/services/user.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css'],
})
export class NavComponent implements OnInit {
  audio: any;
  songs: any;
  isShow: any = true;
  // id: any = this.r.snapshot.paramMap.get('id')!;
  id: string = '636cf6916f5c2aff4a27fe7b';
  constructor(
    private r: ActivatedRoute,
    private api: SongService,
    private s: UserService,
    private l: Location
  ) {}

  ngOnInit(): void {
    this.audio = new Audio();
    console.log('h');

    this.api.getAll().subscribe((data) => {
      this.songs = data;
    });
  }

  startPlayer(s: string) {
    this.audio.src = s;
    this.audio.load();
    this.audio.play();
    this.isShow = false;
  }
  pausePlayer() {
    this.audio.pause();
    this.isShow = true;
  }

  follow(s: string) {
    console.log(s);
    s = s.toString();
    this.s.follow(this.id, s).subscribe((data) => {
      console.log(data);
      alert('follo');
    });
  }

  goback() {
    this.l.back();
  }
  goforward() {
    this.l.forward();
  }
}

