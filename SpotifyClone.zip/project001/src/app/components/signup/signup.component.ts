import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { LoginComponent } from '../login/login.component';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
})
export class SignupComponent implements OnInit {
  signup!: FormGroup;
  constructor(
    private fb: FormBuilder,
    private api: UserService,
    private router: Router,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.signup = this.fb.group({
      name: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  submit() {
    if (this.signup.valid) {
      let d = {
        name: this.signup.value.name,
        password: this.signup.value.password,
        liked: ['string'],
        totalPlaylists: [
          {
            playlistName: 'string',
            playlists: ['string'],
          },
        ],
      };

      this.api.postDetails(d).subscribe({
        next: (response) => {
          alert('signup is successful');
          this.signup.reset();
          this.dialog.open(LoginComponent, {
            width: '30%',
          });
        },
        error: () => {
          alert('signup is not successful');
        },
      });
    }
  }
}
