import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class SongService {
  url: string = 'https://localhost:5001/api/Playlist/';
  constructor(private h: HttpClient) {}

  getAll() {
    return this.h.get<any>(this.url);
  }

  updatePlaylist(id: string, data: any) {
    return this.h.put<any>(this.url + id, data);
  }

  getPlaylist(id: string) {
    return this.h.get<any>(this.url + id);
  }
}

