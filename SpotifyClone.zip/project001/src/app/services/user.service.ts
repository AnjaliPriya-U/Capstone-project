import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  baseURL: string = 'https://localhost:5001/api/Crud';
  songURL: string = 'https://localhost:5001/api/Song';
  playlistURL: string = 'https://localhost:5001/api/Playlist/';

  constructor(private h: HttpClient) {}

  getDetails() {
    return this.h.get<any>(this.baseURL);
  }

  postDetails(data: any) {
    return this.h.post<any>(this.baseURL, data);
  }

  putInfo(data: any, id: Number) {
    return this.h.put<any>(this.baseURL + id, data);
  }
  getById(id: string) {
    return this.h.get<any>(this.baseURL + id);
  }
  update(id: string, data: any) {
    return this.h.put<any>(this.baseURL + id, data);
  }
  follow(id: string, data: any) {
    return this.h.put<any>(this.baseURL + id, data);
  }
  getSongDetails() {
    return this.h.get<any>(this.songURL);
  }

  u(id: string, data: any) {
    return this.h.put<any>(this.playlistURL + id, data);
  }

  g(id: string) {
    return this.h.get<any>(this.playlistURL + id);
  }
}
