﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson.Serialization.Options;
using System.Collections.Generic;
using System.Net.Sockets;

namespace api.Models
{
    [BsonIgnoreExtraElements]
    public class User
    {
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        [BsonId] 
        public string Id { get; set; } 
        public string Name { get; set; } 
        public string Password { get; set; } 
        public List<string> Liked { get; set; }
        public List<Playlist> TotalPlaylists { get; set; }
    }
    public class Playlist
    { 
        public string PlaylistName { get; set; }
        public string[] Playlists { get; set; } 

    }

}
