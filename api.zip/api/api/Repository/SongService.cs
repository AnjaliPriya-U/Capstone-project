﻿using api.Models;
using MongoDB.Driver;
using System.Collections.Generic;

namespace api.Repository
{
    public class SongService: IRepository.ISongService
    {
        private MongoClient _client;
        private IMongoDatabase _database; 
        private IMongoCollection<Song> _songs;
        private IMongoCollection<Song> _playlists; 

        public SongService()
        {
            _client = new MongoClient("mongodb+srv://root:root@cluster0.qhn8kwi.mongodb.net/test");
            _database = _client.GetDatabase("spotify"); 
            _songs = _database.GetCollection<Song>("songs");
            _playlists = _database.GetCollection<Song>("playlist");
        }

        public List<Song> GetSongs() => _songs.Find(song => true).ToList(); 
        public Song GetSong(string id) => _songs.Find(user => user.Id == id).First(); 
        public List<Song> GetPlaylists() => _playlists.Find(song => true).ToList(); 
    }
}

