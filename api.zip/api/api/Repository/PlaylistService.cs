﻿using api.Models;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;

namespace api.Repository
{
    public class PlaylistService: IRepository.IPlaylistService
    {
        private MongoClient _client;
        private IMongoDatabase _database;
        private IMongoCollection<User> _users;
        private IMongoCollection<Song> _songs;
        private IMongoCollection<Song> _playlists; 

        public PlaylistService()
        {
            _client = new MongoClient("mongodb+srv://root:root@cluster0.qhn8kwi.mongodb.net/test");
            _database = _client.GetDatabase("spotify");
            _users = _database.GetCollection<User>("user");
            _songs = _database.GetCollection<Song>("songs");
            _playlists = _database.GetCollection<Song>("playlist");
        }
        public List<Song> GetAll() => _playlists.Find(user => true).ToList();
        public User AddUser(User user)
        {
            _users.InsertOne(user);
            return user;
        }
        public User GetUser(string id)
        {
            var values = _users.Find(user => user.Id == id).First(); 
            return values;
        }

        public void DeleteUser(string id,Playlist p)
        {
            var values = _users.Find(user => user.Id == id).First();
            var filter = Builders<User>.Filter.Eq("Id", id);  
            _users.DeleteOne(filter);
            return; 
        }
        public User PutUser(string id, User user)
        {
            _users.ReplaceOne(user => user.Id == id, user);
            return user;
        }

        public void UpdateRecord(string id, Playlist p)
        {  
            Console.WriteLine(p);
            var filter = Builders<User>.Filter.Eq("Id", id); 
            var update = Builders<User>.Update.AddToSet("TotalPlaylists", p); 
            _users.UpdateOne(filter, update); 
            return; 
        }

        public void UpdateFollow(string id, string l)
        {
            var filter = Builders<User>.Filter.Eq("Id", id);
            UpdateDefinition<User> update = Builders<User>.Update.AddToSet("Liked", l);
            _users.UpdateOne(filter, update);
            return; 
        }

        public void DeletePlaylist(string id, string n, Playlist p)
        { 
            var values = _users.Find(user => user.Id == id).First();
            var deleteFilter = Builders<User>.Filter.Eq("PlaylistName", n);
            _users.DeleteOne(deleteFilter); 

        }
    }
}
