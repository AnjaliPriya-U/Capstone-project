﻿using api.Models;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using System.Threading.Tasks;
using static MongoDB.Driver.WriteConcern;

namespace api.Repository
{
    public class UserService : IRepository.IUserService
    {
        private MongoClient _client;
        private IMongoDatabase _database;
        private IMongoCollection<User> _users;
        private IMongoCollection<Song> _songs; 

        public UserService()
        {
            _client = new MongoClient("mongodb+srv://root:root@cluster0.qhn8kwi.mongodb.net/test");
            _database = _client.GetDatabase("spotify");
            _users = _database.GetCollection<User>("user");
            _songs = _database.GetCollection<Song>("songs");
        }
        public List<User> GetAll() => _users.Find(user => true).ToList(); 
        public User AddUser(User user)
        {
            _users.InsertOne(user);
            return user;
        }

        public User GetUser(string id) => _users.Find(user => user.Id == id).First(); 

        public void DeleteUser(string id) => _users.DeleteOne(user => user.Id == id); 

        public List<Song> GetSongs() => _songs.Find(song => true).ToList(); 

        public void UpdateFollow(string id, [FromBody] string l)
        {
            var filter = Builders<User>.Filter.Eq("Id", id);
            UpdateDefinition<User> update = Builders<User>.Update.AddToSet("Liked", l);
            _users.UpdateOne(filter, update);
            return;
        }
         
    }
}