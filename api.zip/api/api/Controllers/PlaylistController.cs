﻿using api.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlaylistController : ControllerBase
    {
        private readonly IRepository.IPlaylistService playlistService1;
        public PlaylistController(IRepository.IPlaylistService playlistService)
        {
            playlistService1 = playlistService;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(playlistService1.GetAll());
        }

        [HttpGet("{id}", Name = "GetPlaylist")]
        public IActionResult GetUser(string id)
        {
            return Ok(playlistService1.GetUser(id));
        } 

        [HttpPost]
        public IActionResult AddUser(User user)
        {
            playlistService1.AddUser(user);
            return CreatedAtRoute("GetUser", new { id = user.Id }, user);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteUser(string id, Playlist p)
        {
            playlistService1.DeleteUser(id,p);
            return NoContent();
        } 

        [HttpPut("{id}")]
        public IActionResult UpdateRecord(string id, [FromBody] Playlist p)
        {
            playlistService1.UpdateRecord(id, p);
            return NoContent();
        } 
    }
}