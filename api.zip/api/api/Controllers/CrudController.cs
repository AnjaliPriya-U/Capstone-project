﻿using api.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using System.Threading.Tasks;

namespace api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CrudController : ControllerBase
    {
        private readonly IRepository.IUserService userService1;
        public CrudController(IRepository.IUserService userService)
        {
            userService1 = userService;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(userService1.GetAll());
        } 

        [HttpGet("{id}", Name ="GetUser")]
        public IActionResult GetUser(string id)
        {
            return Ok(userService1.GetUser(id));
        }
     
        [HttpPost]
        public IActionResult AddUser(User user)
        {
            userService1.AddUser(user);
            return CreatedAtRoute("GetUser", new { id = user.Id }, user);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteUser(string id)
        {
            userService1.DeleteUser(id);
            return NoContent();
        } 

        [HttpPut("{id}")]
        public IActionResult PutUser(string id, [FromBody] string l)
        {
            userService1.UpdateFollow(id, l);
            return NoContent();
        } 
    } 

}
