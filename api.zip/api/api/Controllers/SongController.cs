﻿using api.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SongController : ControllerBase
    {
        private readonly IRepository.ISongService songService1;
        public SongController(IRepository.ISongService songService)
        {
            songService1 = songService;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(songService1.GetSongs());
        }

        [HttpGet("{id}", Name = "GetSong")]
        public IActionResult GetSong(string id)
        {
            return Ok(songService1.GetSong(id));
        }


    }
}
