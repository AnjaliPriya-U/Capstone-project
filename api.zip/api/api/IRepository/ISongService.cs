﻿using api.Repository;
using api.Models;
using System.Collections.Generic;

namespace api.IRepository
{
    public interface ISongService
    {
        List<Song> GetSongs();
        Song GetSong(string id);
        List<Song> GetPlaylists();
    }
}
