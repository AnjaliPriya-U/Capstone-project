﻿using api.Models;
using System.Collections.Generic;

namespace api.IRepository
{
    public interface IPlaylistService
    {
        List<Song> GetAll();
        User AddUser(User user);
        User GetUser(string id); 
        void DeleteUser(string id,Playlist p);
        User PutUser(string id, User user); 
        void UpdateRecord(string id, Playlist p);
        void UpdateFollow(string id, string l);
        void DeletePlaylist(string id, string n, Playlist p);


    }
}
