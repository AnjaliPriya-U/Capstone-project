﻿using api.Repository;
using System.Collections.Generic;
using api.Models;
using MongoDB.Bson;
using System.Threading.Tasks;

namespace api.IRepository
{
    public interface IUserService
    {
        List<User> GetAll(); 
        User AddUser(User user); 
        User GetUser(string id); 
        void DeleteUser(string id);     
        void UpdateFollow(string id, string l); 
    }
}
